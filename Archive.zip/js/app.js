/*globals simpleCart */

$(document).foundation();

jQuery(document).ready(function($){

	$(function() {
	    FastClick.attach(document.body);
	});

	
/*
 * Tab System
 * ================================================================================ */	
	
/*
    $(".button1").click(function(){
        $(".menu2, .menu3, .menu4, .menu5").hide();
		$(".menu1").show();
    });
    $(".button2").click(function(){
        $(".menu1, .menu3, .menu4, .menu5").hide();
		$(".menu2").show();
    });
    $(".button3").click(function(){
        $(".menu1, .menu2, .menu4, .menu5").hide();
		$(".menu3").show();
    });
    $(".button4").click(function(){
        $(".menu1, .menu2, .menu3, .menu5").hide();
		$(".menu4").show();
    });
    $(".button5").click(function(){
        $(".menu1, .menu2, .menu3, .menu4").hide();
		$(".menu5").show();
    });
*/

   $(".button").each(function(i){ // "i" means index.
        i++; // Starts the first index at 1 instead of 0.
            
        $(this).click(function(){
            // Styling class for the tab.
            $(this).parent().find('.active-tab').removeClass('active-tab');
            $(this).addClass('active-tab');
        
            // Hide / Show for menus
            $(".menus").children().hide();
            $(".menus").find(".menu" + i).show();
        });
    });


/*
 * Column Height
 * ================================================================================ */	
 
 	$(function(){
	 	var windowHeight = $(window).height(),
	 		headerHeight = $(".header").outerHeight(),
	 		columnHeight = windowHeight - headerHeight;
	 		
	 		console.log(windowHeight);
	 		console.log(headerHeight);
	 		console.log(columnHeight);
	 		
	 	$(window).load(function(){
		 	$('.e-column').each(function(){
			 	$(this).height(columnHeight);
		 	});
		 });
 	});
 
/*
 * Foundation Reveal Extras
 * ================================================================================ */	

	$('.item_add').click(function(){
		$(this).foundation('reveal', 'close');
		//$('.item_note').val('');
	});


/*
 * Simplecart Config
 * ================================================================================ */	

	simpleCart({
	    cartColumns: [
		    { attr: "quantity", label: "QTY" },
	        { attr: "name", label: "Item" },
	        //{ attr: "price" , label: "Price", view: 'currency' } ,
	        { attr: "total", label: "SubTotal", view: 'currency' },
	        { view: "remove", text: " ", label: false },
	        { view: function(item, column){
					return item.get("note");
				}, attr: "note" ,label: false
			},
	    ],
	    cartStyle: "table", 
	    checkout: { 
	        type: "SendForm" , 
	        url: "http://posttestserver.com/post.php" ,
	
	        // http method for form, "POST" or "GET", default is "POST"
	        method: "POST" , 
	
	        // url to return to on successful checkout, default is null
	        success: "success.html" , 
	
	        // url to return to on cancelled checkout, default is null
	        cancel: "cancel.html" ,
	
	        // an option list of extra name/value pairs that can
	        // be sent along with the checkout data
	        extra_data: {
	        }
	    } 
	});


});